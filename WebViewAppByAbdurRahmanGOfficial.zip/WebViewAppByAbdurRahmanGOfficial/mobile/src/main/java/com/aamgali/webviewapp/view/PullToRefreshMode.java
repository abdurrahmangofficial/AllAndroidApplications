package com.aamgali.webviewapp.view;

public enum PullToRefreshMode {ENABLED, PROGRESS, DISABLED}
