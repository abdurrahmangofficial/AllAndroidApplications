package com.aamgali.webviewapp.listener;

public interface DrawerStateListener {
	boolean isDrawerOpen();
	void onBackButtonPressed();
}
