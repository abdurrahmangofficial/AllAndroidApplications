package com.aamgali.webviewapp.listener;

public interface LoadUrlListener {
	void onLoadUrl(String url);
}
